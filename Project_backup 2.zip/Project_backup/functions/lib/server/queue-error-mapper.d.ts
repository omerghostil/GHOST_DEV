export interface QueueHttpErrorMapping {
    statusCode: number;
    errorMessage: string;
}
/**
 * ממיר שגיאות תור/AI לתגובת HTTP ברורה למשתמש, בלי לחשוף קודי שגיאה פנימיים.
 */
export declare function mapQueueErrorToHttp(error: unknown, actionLabel: string): QueueHttpErrorMapping;
//# sourceMappingURL=queue-error-mapper.d.ts.map