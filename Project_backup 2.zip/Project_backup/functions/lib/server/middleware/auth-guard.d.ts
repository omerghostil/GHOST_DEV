import type { NextFunction, Request, Response } from 'express';
import type { UserRole } from '../admin/types';
export interface RequestAuthContext {
    userId: string;
    organizationId: string;
    organizationName: string;
    role: UserRole;
    username: string;
    firstName: string;
    lastName: string;
}
declare module 'express-serve-static-core' {
    interface Request {
        auth?: RequestAuthContext;
    }
}
/**
 * מאמת access token ומוסיף הקשר משתמש לבקשה.
 */
export declare function requireAuth(request: Request, response: Response, next: NextFunction): void;
/**
 * בודק הרשאות role לפי רשימת תפקידים מותרת.
 */
export declare function requireRoles(allowedRoles: UserRole[]): (request: Request, response: Response, next: NextFunction) => void;
//# sourceMappingURL=auth-guard.d.ts.map