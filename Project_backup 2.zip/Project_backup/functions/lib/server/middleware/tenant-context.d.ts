import type { Request } from 'express';
import type { RequestAuthContext } from './auth-guard';
export interface TenantContext {
    organizationId: string;
    userId: string;
    role: RequestAuthContext['role'];
}
/**
 * מחלץ tenant context מה-JWT בלבד — לעולם לא מ-body/query.
 * זורק שגיאה אם אין auth context.
 */
export declare function extractTenantContext(request: Request): TenantContext;
//# sourceMappingURL=tenant-context.d.ts.map