/**
 * שגיאה שמייצגת כשל שאינו זמני (כמו מפתח API לא תקין).
 * Circuit Breaker לא סופר אותה, ו-retry לא מנסה שוב.
 */
export declare class NonRetryableAiError extends Error {
    constructor(message: string);
}
//# sourceMappingURL=non-retryable-ai-error.d.ts.map