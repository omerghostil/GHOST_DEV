import type { VisionDetailLevel } from './image-optimizer';
export type VisionModelName = 'gpt-4.1' | 'gpt-4.1-mini';
export interface ModelSelectionArgs {
    task: 'chat' | 'scan';
    triggerText?: string;
    modelOverride?: VisionModelName;
}
export interface DetailSelectionArgs {
    task: 'chat' | 'scan';
    triggerText?: string;
    detailOverride?: VisionDetailLevel;
}
/**
 * מזהה טריגר מורכב שדורש מודל חזק יותר להבנת סיטואציות מרובות עצמים.
 */
export declare function isComplexTrigger(triggerText: string | undefined): boolean;
/**
 * בוחר מודל מתאים לפי סוג משימה, טריגר, והעדפה ידנית של המבצע.
 */
export declare function selectVisionModel(args: ModelSelectionArgs): VisionModelName;
/**
 * בוחר רמת פירוט תמונה מאוזנת בין איכות, מהירות ועלות.
 */
export declare function selectVisionDetailLevel(args: DetailSelectionArgs): VisionDetailLevel;
//# sourceMappingURL=model-selector.d.ts.map