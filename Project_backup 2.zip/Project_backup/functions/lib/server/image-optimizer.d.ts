export type VisionDetailLevel = 'low' | 'auto' | 'high';
export type ImageProfileKey = 'scan-low' | 'scan-standard' | 'chat-high';
export interface OptimizedImageResult {
    dataUrl: string;
    width: number;
    height: number;
    byteSize: number;
    detail: VisionDetailLevel;
}
/**
 * דוחס ומבצע resize לתמונה כדי להפחית עלויות טוקנים וזמן העלאה.
 */
export declare function optimizeImageDataUrl(dataUrl: string, profileKey: ImageProfileKey): Promise<OptimizedImageResult>;
export declare function getImageProfileByTask(task: 'chat' | 'scan', isComplexScan: boolean): ImageProfileKey;
//# sourceMappingURL=image-optimizer.d.ts.map