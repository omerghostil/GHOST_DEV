import 'dotenv/config';
import express from 'express';
import type { IAdminRepository } from './db/repository-types';
import type { IRealtimeHub } from './realtime/realtime-hub-types';
/**
 * יוצר ומגדיר את ה-Express application עם כל הנתיבים.
 */
export declare function createApp(store: IAdminRepository, realtimeHub: IRealtimeHub): express.Application;
//# sourceMappingURL=app.d.ts.map