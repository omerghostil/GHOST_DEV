/**
 * שכבת SyncIntent — מסמנת אילו אירועים מיועדים לסנכרון ענן עתידי.
 * כרגע No-Op מלא: שום דבר לא נשלח לענן.
 * בעת מעבר ל-Firebase — המימוש כאן יוחלף בכתיבה ל-Realtime Database.
 */
export type SyncTargetType = 'realtime' | 'firestore';
export interface SyncIntentRecord {
    entityType: string;
    entityId: string;
    action: 'create' | 'update' | 'delete';
    target: SyncTargetType;
    payload: Record<string, unknown>;
}
/**
 * סימון אירוע לסנכרון ענן עתידי.
 * כרגע No-Op — אין שליחה בפועל.
 */
export declare function markForCloudSync(_intent: SyncIntentRecord): void;
/**
 * מיפוי סכמת SQLite לוקלי לסכמת Firebase עתידית.
 *
 * Firestore (DB רגיל — ישויות ליבה):
 *   organizations/{orgId}           -> OrganizationRecord
 *   organizations/{orgId}/users/{userId}    -> UserRecord
 *   organizations/{orgId}/channels/{chId}   -> ChannelRecord
 *   organizations/{orgId}/campaigns/{cId}   -> CampaignRecord
 *   organizations/{orgId}/limits            -> OrganizationLimits (subcollection)
 *   organizations/{orgId}/payment_card      -> PaymentCardRecord (single doc)
 *   organizations/{orgId}/issues/{issueId}  -> IssueRecord
 *   audit_logs/{logId}                      -> AuditLogRecord
 *   usage_ledger/{entryId}                  -> UsageLedgerRecord
 *
 * Realtime Database (אירועים חיים וסטטוסים):
 *   live/usage_events/{eventId}             -> UsageEventRecord
 *   live/channel_usage/{orgId}/{chId}/{monthKey} -> ChannelUsageMonthlyRecord
 *   live/org_usage/{orgId}                  -> OrganizationUsage (aggregate)
 *
 * refresh_tokens -> Firebase Auth custom claims (לא ב-DB)
 */
export declare const FIREBASE_SCHEMA_MAP: {
    readonly firestore: {
        readonly organizations: "organizations/{orgId}";
        readonly users: "organizations/{orgId}/users/{userId}";
        readonly channels: "organizations/{orgId}/channels/{chId}";
        readonly campaigns: "organizations/{orgId}/campaigns/{cId}";
        readonly paymentCards: "organizations/{orgId}/payment_card";
        readonly issues: "organizations/{orgId}/issues/{issueId}";
        readonly auditLogs: "audit_logs/{logId}";
        readonly usageLedger: "usage_ledger/{entryId}";
    };
    readonly realtime: {
        readonly usageEvents: "live/usage_events/{eventId}";
        readonly channelUsage: "live/channel_usage/{orgId}/{chId}/{monthKey}";
        readonly orgUsageAggregate: "live/org_usage/{orgId}";
    };
};
//# sourceMappingURL=sync-intent.d.ts.map