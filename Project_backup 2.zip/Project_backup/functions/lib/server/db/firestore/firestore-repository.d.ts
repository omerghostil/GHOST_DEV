import type { AuditLogRecord, CampaignRecord, ChannelRecord, FullChannelRecord, IssueRecord, MessageRecord, OperationRecord, OperationRunRecord, OrganizationLimits, OrganizationRecord, OrganizationUsage, PaymentCardRecord, RefreshTokenRecord, UsageLedgerRecord, UserRecord, UserRole } from '../../admin/types';
import type { ChannelUsageField, ChannelUsageMonthlyRecord, IAdminRepository, UsageEventRecord } from '../repository-types';
/**
 * מימוש Firestore ל-IAdminRepository עם write-through cache בזיכרון.
 * קריאות — מהירות מה-cache. כתיבות — עדכון cache ו-Firestore בו-זמנית.
 * מטעין את כל הנתונים בפעם הראשונה שנדרשים.
 */
export declare class FirestoreAdminRepository implements IAdminRepository {
    private cache;
    private loadPromise;
    /** טוען את כל הנתונים מ-Firestore למטמון בפעם הראשונה. */
    private ensureLoaded;
    private loadAll;
    /** מבצע פעולה אחרי טעינת cache. משתמש ב-waitUntilLoaded אם cache עדיין לא טעון. */
    private run;
    /** מאתחל את ה-repository ומטעין נתונים ראשוניים. */
    initialize(): Promise<void>;
    listOrganizations(): OrganizationRecord[];
    getOrganizationById(organizationId: string): OrganizationRecord | undefined;
    createOrganization(input: {
        name: string;
        limits: OrganizationLimits;
    }): OrganizationRecord;
    updateOrganization(organizationId: string, updater: (org: OrganizationRecord) => OrganizationRecord): OrganizationRecord;
    listUsersByOrganization(organizationId?: string): UserRecord[];
    findUserByUsername(username: string): UserRecord | undefined;
    findUserById(userId: string): UserRecord | undefined;
    createUser(input: {
        organizationId: string;
        username: string;
        firstName?: string;
        lastName?: string;
        firebaseUid?: string;
        passwordHash: string;
        role: UserRole;
        allowedChannelIds: string[];
        blockedChannelIds: string[];
    }): UserRecord;
    updateUser(userId: string, updater: (user: UserRecord) => UserRecord): UserRecord;
    updateUserLastLogin(userId: string, atIso: string): void;
    listChannels(organizationId: string): ChannelRecord[];
    createChannel(input: {
        organizationId: string;
        name: string;
    }): ChannelRecord;
    listCampaigns(organizationId: string): CampaignRecord[];
    createCampaign(input: {
        organizationId: string;
        name: string;
    }): CampaignRecord;
    upsertPaymentCard(card: PaymentCardRecord): PaymentCardRecord;
    getPaymentCard(organizationId: string): PaymentCardRecord | undefined;
    updateOrganizationOpenAiKey(organizationId: string, encryptedKey: string): OrganizationRecord;
    addUsageLedgerEntry(entry: Omit<UsageLedgerRecord, 'id' | 'createdAtIso'>): UsageLedgerRecord;
    listUsageLedger(organizationId?: string): UsageLedgerRecord[];
    updateOrganizationUsage(organizationId: string, updater: (usage: OrganizationUsage) => OrganizationUsage): OrganizationRecord;
    getChannelUsageMonthly(organizationId: string, monthKey?: string): ChannelUsageMonthlyRecord[];
    incrementChannelUsage(input: {
        organizationId: string;
        channelId: string;
        monthKey: string;
        field: ChannelUsageField;
        count?: number;
    }): void;
    addUsageEvent(input: Omit<UsageEventRecord, 'id' | 'createdAtIso'>): UsageEventRecord;
    createIssue(input: {
        organizationId: string;
        userId: string;
        title: string;
        description: string;
        severity: IssueRecord['severity'];
    }): IssueRecord;
    listIssues(): IssueRecord[];
    updateIssue(issueId: string, updater: (issue: IssueRecord) => IssueRecord): IssueRecord;
    addAuditLog(input: Omit<AuditLogRecord, 'id' | 'createdAtIso'>): AuditLogRecord;
    listAuditLogs(limit?: number): AuditLogRecord[];
    storeRefreshToken(record: RefreshTokenRecord): void;
    hasRefreshToken(tokenId: string, userId: string): boolean;
    revokeRefreshToken(tokenId: string): void;
    purgeExpiredRefreshTokens(nowUnix?: number): void;
    countFullChannels(organizationId: string): Promise<number>;
    countMessages(organizationId: string): Promise<number>;
    countMessagesByAuthor(organizationId: string): Promise<{
        sent: number;
        received: number;
    }>;
    countOperations(organizationId: string): Promise<number>;
    private channelDataCol;
    listFullChannels(organizationId: string): Promise<FullChannelRecord[]>;
    getFullChannel(organizationId: string, channelId: string): Promise<FullChannelRecord | undefined>;
    createFullChannel(organizationId: string, data: Omit<FullChannelRecord, 'id' | 'organizationId' | 'createdAtIso' | 'updatedAtIso'>): Promise<FullChannelRecord>;
    updateChannelData(organizationId: string, channelId: string, fields: Partial<Omit<FullChannelRecord, 'id' | 'organizationId' | 'createdAtIso'>>): Promise<FullChannelRecord>;
    deleteFullChannel(organizationId: string, channelId: string): Promise<void>;
    private messagesCol;
    addMessage(organizationId: string, userId: string, channelId: string, message: Omit<MessageRecord, 'id' | 'organizationId' | 'userId' | 'channelId' | 'createdAtIso'>): Promise<MessageRecord>;
    listMessages(organizationId: string, userId: string, channelId: string, opts?: {
        limit?: number;
        beforeIso?: string;
    }): Promise<MessageRecord[]>;
    clearMessageFrame(organizationId: string, userId: string, channelId: string, messageId: string): Promise<void>;
    private operationsCol;
    createChannelOperation(organizationId: string, channelId: string, op: Omit<OperationRecord, 'id' | 'organizationId' | 'channelId' | 'createdAtIso' | 'updatedAtIso'>): Promise<OperationRecord>;
    listChannelOperations(organizationId: string, channelId: string): Promise<OperationRecord[]>;
    updateChannelOperation(organizationId: string, channelId: string, opId: string, fields: Partial<Omit<OperationRecord, 'id' | 'organizationId' | 'channelId' | 'createdAtIso'>>): Promise<OperationRecord>;
    deleteChannelOperation(organizationId: string, channelId: string, opId: string): Promise<void>;
    listAllOperations(organizationId: string): Promise<OperationRecord[]>;
    listRecentOperationRuns(organizationId: string, limit?: number): Promise<OperationRunRecord[]>;
    listRunnableOperations(): Promise<OperationRecord[]>;
    acquireOperationRunLock(organizationId: string, channelId: string, operationId: string): Promise<OperationRunRecord | null>;
    completeOperationRun(runId: string): Promise<OperationRunRecord>;
    failOperationRun(runId: string, errorCode: string, errorMessage: string): Promise<OperationRunRecord>;
}
//# sourceMappingURL=firestore-repository.d.ts.map