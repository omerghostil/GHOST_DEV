import type { AuditLogRecord, CampaignRecord, ChannelRecord, IssueRecord, OrganizationLimits, OrganizationRecord, PaymentCardRecord, RefreshTokenRecord, UsageLedgerRecord, UserRecord, UserRole } from '../admin/types';
/**
 * שכבת אחסון קבצים פשוטה לצרכי ניהול סופר־אדמין עם persistence.
 */
export declare class AdminDataStore {
    private state;
    constructor();
    private loadState;
    private persistState;
    listOrganizations(): OrganizationRecord[];
    getOrganizationById(organizationId: string): OrganizationRecord | undefined;
    createOrganization(input: {
        name: string;
        limits: OrganizationLimits;
    }): OrganizationRecord;
    updateOrganization(organizationId: string, updater: (organization: OrganizationRecord) => OrganizationRecord): OrganizationRecord;
    listUsersByOrganization(organizationId?: string): UserRecord[];
    findUserByUsername(username: string): UserRecord | undefined;
    findUserById(userId: string): UserRecord | undefined;
    createUser(input: {
        organizationId: string;
        username: string;
        passwordHash: string;
        role: UserRole;
        allowedChannelIds: string[];
        blockedChannelIds: string[];
    }): UserRecord;
    updateUser(userId: string, updater: (user: UserRecord) => UserRecord): UserRecord;
    updateUserLastLogin(userId: string, atIso: string): void;
    listChannels(organizationId: string): ChannelRecord[];
    createChannel(input: {
        organizationId: string;
        name: string;
    }): ChannelRecord;
    listCampaigns(organizationId: string): CampaignRecord[];
    createCampaign(input: {
        organizationId: string;
        name: string;
    }): CampaignRecord;
    upsertPaymentCard(card: PaymentCardRecord): PaymentCardRecord;
    getPaymentCard(organizationId: string): PaymentCardRecord | undefined;
    updateOrganizationOpenAiKey(organizationId: string, encryptedOpenAiApiKey: string): OrganizationRecord;
    addUsageLedgerEntry(entry: Omit<UsageLedgerRecord, 'id' | 'createdAtIso'>): UsageLedgerRecord;
    listUsageLedger(organizationId?: string): UsageLedgerRecord[];
    updateOrganizationUsage(organizationId: string, updater: (usage: OrganizationRecord['usage']) => OrganizationRecord['usage']): OrganizationRecord;
    createIssue(input: {
        organizationId: string;
        userId: string;
        title: string;
        description: string;
        severity: IssueRecord['severity'];
    }): IssueRecord;
    listIssues(): IssueRecord[];
    updateIssue(issueId: string, updater: (issue: IssueRecord) => IssueRecord): IssueRecord;
    addAuditLog(input: Omit<AuditLogRecord, 'id' | 'createdAtIso'>): AuditLogRecord;
    listAuditLogs(limit?: number): AuditLogRecord[];
    storeRefreshToken(record: RefreshTokenRecord): void;
    hasRefreshToken(tokenId: string, userId: string): boolean;
    revokeRefreshToken(tokenId: string): void;
    purgeExpiredRefreshTokens(nowUnix?: number): void;
}
//# sourceMappingURL=admin-data-store.d.ts.map