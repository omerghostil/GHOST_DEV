import { z } from 'zod';
export declare const ChannelSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    type: z.ZodEnum<{
        personal: "personal";
        group: "group";
    }>;
    watchScope: z.ZodString;
    location: z.ZodString;
    members: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export declare const ChatVisionRequestSchema: z.ZodObject<{
    channel: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodEnum<{
            personal: "personal";
            group: "group";
        }>;
        watchScope: z.ZodString;
        location: z.ZodString;
        members: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    prompt: z.ZodString;
    frameDataUrl: z.ZodString;
    analysisContext: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type ChatVisionRequest = z.infer<typeof ChatVisionRequestSchema>;
export declare const OperationScanRequestSchema: z.ZodObject<{
    channel: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodEnum<{
            personal: "personal";
            group: "group";
        }>;
        watchScope: z.ZodString;
        location: z.ZodString;
        members: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    frameDataUrl: z.ZodString;
    operations: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        schedule: z.ZodString;
        mode: z.ZodEnum<{
            alert: "alert";
            report: "report";
            rating: "rating";
            assessment: "assessment";
        }>;
        alertTrigger: z.ZodString;
        action: z.ZodString;
        modelOverride: z.ZodOptional<z.ZodEnum<{
            "gpt-4.1": "gpt-4.1";
            "gpt-4.1-mini": "gpt-4.1-mini";
        }>>;
        detailLevel: z.ZodOptional<z.ZodEnum<{
            low: "low";
            auto: "auto";
            high: "high";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type OperationScanRequest = z.infer<typeof OperationScanRequestSchema>;
export declare const OperationScanResponseSchema: z.ZodObject<{
    results: z.ZodArray<z.ZodObject<{
        operationId: z.ZodString;
        mode: z.ZodEnum<{
            alert: "alert";
            report: "report";
            rating: "rating";
            assessment: "assessment";
        }>;
        critical: z.ZodOptional<z.ZodBoolean>;
        score: z.ZodOptional<z.ZodNumber>;
        summary: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type OperationScanResponse = z.infer<typeof OperationScanResponseSchema>;
//# sourceMappingURL=schemas.d.ts.map