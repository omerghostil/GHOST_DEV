export type CircuitBreakerState = 'closed' | 'open' | 'half-open';
export interface CircuitBreakerConfig {
    failureThreshold: number;
    resetTimeoutMs: number;
    halfOpenMaxAttempts: number;
}
export interface CircuitBreakerSnapshot {
    state: CircuitBreakerState;
    consecutiveFailures: number;
    openedAt: number | null;
    halfOpenAttempts: number;
}
/**
 * מגן על קריאות לספק חיצוני בזמן תקלות מתמשכות, כדי למנוע עומס ותקיעות.
 */
export declare class CircuitBreaker {
    private readonly config;
    private state;
    private consecutiveFailures;
    private openedAt;
    private halfOpenAttempts;
    constructor(config?: Partial<CircuitBreakerConfig>);
    /**
     * מריץ פעולה תחת מעקב Circuit Breaker ומחליט האם לחסום או לאפשר אותה.
     */
    execute<T>(operation: () => Promise<T>): Promise<T>;
    getSnapshot(): CircuitBreakerSnapshot;
    /**
     * מיועד לבדיקות כדי לאפס את מצב המנגנון בצורה נקייה.
     */
    resetForTests(): void;
    private onSuccess;
    private onFailure;
    private openCircuit;
    private transitionStateIfNeeded;
}
//# sourceMappingURL=circuit-breaker.d.ts.map