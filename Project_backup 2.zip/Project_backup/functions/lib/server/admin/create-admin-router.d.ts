import { Router } from 'express';
import type { IAdminRepository } from '../db/repository-types';
import type { IRealtimeHub } from '../realtime/realtime-hub-types';
interface CreateAdminRouterOptions {
    store: IAdminRepository;
    realtimeHub: IRealtimeHub;
}
/**
 * יוצר נתיבי API עבור ניהול ארגונים, משתמשים, חיובים, שימוש ותקלות.
 */
export declare function createAdminRouter({ store, realtimeHub }: CreateAdminRouterOptions): Router;
export {};
//# sourceMappingURL=create-admin-router.d.ts.map