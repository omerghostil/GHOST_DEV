import { z } from 'zod';
export declare const LoginRequestSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
}, z.core.$strip>;
export declare const RefreshRequestSchema: z.ZodObject<{
    refreshToken: z.ZodString;
}, z.core.$strip>;
export declare const CreateOrganizationSchema: z.ZodObject<{
    name: z.ZodString;
    limits: z.ZodObject<{
        maxChannels: z.ZodNumber;
        maxMessagesPerChannelPerMonth: z.ZodNumber;
        monthlyChargeAmount: z.ZodNumber;
        maxAgentsTotalCost: z.ZodNumber;
        maxAiTotalCost: z.ZodNumber;
        maxApiTotalCost: z.ZodNumber;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const UpdateOrganizationSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        active: "active";
        suspended: "suspended";
    }>>;
    limits: z.ZodOptional<z.ZodObject<{
        maxChannels: z.ZodNumber;
        maxMessagesPerChannelPerMonth: z.ZodNumber;
        monthlyChargeAmount: z.ZodNumber;
        maxAgentsTotalCost: z.ZodNumber;
        maxAiTotalCost: z.ZodNumber;
        maxApiTotalCost: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const CreateUserSchema: z.ZodObject<{
    organizationId: z.ZodString;
    username: z.ZodString;
    firstName: z.ZodString;
    lastName: z.ZodString;
    password: z.ZodString;
    role: z.ZodEnum<{
        system_manager: "system_manager";
        regular_user: "regular_user";
    }>;
    allowedChannelIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    blockedChannelIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const UpdateUserSchema: z.ZodObject<{
    role: z.ZodOptional<z.ZodEnum<{
        system_manager: "system_manager";
        regular_user: "regular_user";
    }>>;
    isActive: z.ZodOptional<z.ZodBoolean>;
    allowedChannelIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    blockedChannelIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const CreateChannelSchema: z.ZodObject<{
    organizationId: z.ZodString;
    name: z.ZodString;
}, z.core.$strip>;
export declare const CreateCampaignSchema: z.ZodObject<{
    organizationId: z.ZodString;
    name: z.ZodString;
}, z.core.$strip>;
export declare const PaymentCardSchema: z.ZodObject<{
    organizationId: z.ZodString;
    pan: z.ZodString;
    cardholderName: z.ZodString;
    expiryMonth: z.ZodString;
    expiryYear: z.ZodString;
    billingEmail: z.ZodString;
    managerCode: z.ZodString;
}, z.core.$strip>;
export declare const RevealPaymentCardSchema: z.ZodObject<{
    organizationId: z.ZodString;
    managerCode: z.ZodString;
}, z.core.$strip>;
export declare const SetOpenAiKeySchema: z.ZodObject<{
    organizationId: z.ZodString;
    openAiApiKey: z.ZodString;
}, z.core.$strip>;
export declare const RecordUsageSchema: z.ZodObject<{
    organizationId: z.ZodString;
    sentMessages: z.ZodDefault<z.ZodNumber>;
    receivedMessages: z.ZodDefault<z.ZodNumber>;
    devicesCount: z.ZodDefault<z.ZodNumber>;
    channelsCount: z.ZodDefault<z.ZodNumber>;
    operationsCount: z.ZodDefault<z.ZodNumber>;
    aiTotalCost: z.ZodDefault<z.ZodNumber>;
    apiTotalCost: z.ZodDefault<z.ZodNumber>;
    agentsTotalCost: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
/** רישום הודעה/מבצע בודד פר ערוץ */
export declare const RecordChannelMessageSchema: z.ZodObject<{
    organizationId: z.ZodString;
    channelId: z.ZodString;
    direction: z.ZodEnum<{
        outgoing: "outgoing";
        incoming: "incoming";
    }>;
    source: z.ZodEnum<{
        user: "user";
        system: "system";
        ghost: "ghost";
        operation: "operation";
    }>;
    campaignId: z.ZodOptional<z.ZodString>;
    count: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
export declare const CreateIssueSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodString;
    severity: z.ZodEnum<{
        low: "low";
        high: "high";
        critical: "critical";
        medium: "medium";
    }>;
}, z.core.$strip>;
export declare const UpdateIssueSchema: z.ZodObject<{
    status: z.ZodEnum<{
        open: "open";
        in_progress: "in_progress";
        resolved: "resolved";
    }>;
}, z.core.$strip>;
//# sourceMappingURL=schemas.d.ts.map