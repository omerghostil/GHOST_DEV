import type { IAdminRepository } from '../db/repository-types';
import type { OrganizationRecord } from './types';
/**
 * תוצאות חישוב שימוש מנתוני מקור-אמת.
 */
export interface ComputedUsage {
    channelsCount: number;
    sentMessages: number;
    receivedMessages: number;
    operationsCount: number;
}
/**
 * מחשב נתוני שימוש אמיתיים מהטבלאות הפעילות (channel_data, messages, channel_operations).
 */
export declare function computeOrganizationUsage(store: IAdminRepository, organizationId: string): Promise<ComputedUsage>;
/**
 * מסנכרן את שדות organization.usage מול הנתונים האמיתיים בטבלאות.
 * שדות עלות (AI/API/Agents) נשמרים כפי שהם כי הם מנוהלים רק דרך usage-record.
 */
export declare function syncOrganizationUsage(store: IAdminRepository, organizationId: string): Promise<OrganizationRecord>;
/**
 * ריקונסיליאציה מלאה — מסנכרן כל הארגונים ומחזיר דוח פערים.
 */
export declare function reconcileAllOrganizations(store: IAdminRepository): Promise<ReconciliationReport[]>;
export interface ReconciliationDiff {
    field: string;
    stored: number;
    actual: number;
}
export interface ReconciliationReport {
    organizationId: string;
    organizationName: string;
    diffs: ReconciliationDiff[];
}
//# sourceMappingURL=sync-org-usage.d.ts.map