import { Router } from 'express';
import type { IAdminRepository } from '../db/repository-types';
interface CreateAuthRouterOptions {
    store: IAdminRepository;
}
/**
 * יוצר נתיבי אימות מרכזיים: login, refresh, logout, me.
 */
export declare function createAuthRouter({ store }: CreateAuthRouterOptions): Router;
export {};
//# sourceMappingURL=create-auth-router.d.ts.map