import type { UserRole } from '../admin/types';
export interface AuthAccessPayload {
    userId: string;
    organizationId: string;
    organizationName: string;
    role: UserRole;
    username: string;
    firstName: string;
    lastName: string;
}
export interface RefreshPayload {
    tokenId: string;
    userId: string;
}
/**
 * חותם access token קצר לשימוש ב-API.
 */
export declare function signAccessToken(payload: AuthAccessPayload): string;
/**
 * מאמת access token ומחזיר payload תקין.
 */
export declare function verifyAccessToken(token: string): AuthAccessPayload;
/**
 * חותם refresh token ומחזיר גם זמן תפוגה בפורמט UNIX.
 */
export declare function signRefreshToken(payload: RefreshPayload): {
    token: string;
    expiresAtUnix: number;
};
/**
 * מאמת refresh token ומחזיר payload.
 */
export declare function verifyRefreshToken(token: string): RefreshPayload;
//# sourceMappingURL=jwt-service.d.ts.map