import type { IAdminRepository } from '../db/repository-types';
/**
 * יוצר (או מחזיר) משתמש Firebase Auth עבור username.
 */
export declare function createFirebaseUser(username: string, password: string): Promise<string>;
/**
 * מאמת סיסמה מול Firebase Authentication באמצעות REST API.
 */
export declare function verifyFirebasePassword(username: string, password: string): Promise<boolean>;
/**
 * מבטיח שמשתמש bootstrap קיים גם ב-Firebase Auth וגם ב-DB.
 */
export declare function ensureFirebaseBootstrapUser(store: IAdminRepository, username: string, password: string): Promise<void>;
//# sourceMappingURL=firebase-auth-service.d.ts.map