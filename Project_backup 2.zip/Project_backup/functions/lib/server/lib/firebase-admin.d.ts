declare const adminApp: import("firebase-admin/app").App;
export declare const adminDb: FirebaseFirestore.Firestore;
export declare const adminRtdb: import("firebase-admin/database").Database;
export declare const adminAuth: import("firebase-admin/auth").Auth;
export default adminApp;
//# sourceMappingURL=firebase-admin.d.ts.map