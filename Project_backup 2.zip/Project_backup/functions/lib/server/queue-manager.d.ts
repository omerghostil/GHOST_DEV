import { type VisionDetailLevel } from './image-optimizer';
import { type VisionModelName } from './model-selector';
import type { ChatVisionRequest, OperationScanRequest, OperationScanResponse } from './schemas';
export declare enum JobPriority {
    CRITICAL = 1,
    NORMAL = 5,
    LOW = 10
}
type QueueMode = 'redis' | 'direct';
interface QueueRuntimeConfig {
    concurrency: number;
    rateLimitRpm: number;
    attempts: number;
    timeoutMs: number;
}
interface VisionChatJobResult {
    text: string;
    sources: string[];
    model: VisionModelName;
    detail: VisionDetailLevel;
}
/**
 * מכניס בקשת צ'אט לתור ומחזיר תוצאה אחרי סיום העיבוד.
 */
export declare function enqueueVisionChat(payload: ChatVisionRequest, apiKey?: string, priority?: JobPriority): Promise<VisionChatJobResult>;
/**
 * מכניס בקשת סריקת מבצעים לתור ומחזיר תוצאות מאומתות.
 */
export declare function enqueueOperationScan(payload: OperationScanRequest, apiKey?: string, priority?: JobPriority): Promise<OperationScanResponse>;
export declare function getQueueHealth(): Promise<{
    mode: "direct";
    counts: any;
    circuitBreaker: import("./circuit-breaker").CircuitBreakerSnapshot;
    config: QueueRuntimeConfig;
} | {
    mode: "redis";
    counts: {
        chat: {
            [index: string]: number;
        };
        scan: {
            [index: string]: number;
        };
    };
    circuitBreaker: import("./circuit-breaker").CircuitBreakerSnapshot;
    config: QueueRuntimeConfig;
}>;
export declare function closeQueueResourcesForTests(): Promise<void>;
export declare function getQueueModeForTests(): QueueMode;
export declare function getRuntimeConfigForTests(): QueueRuntimeConfig;
export {};
//# sourceMappingURL=queue-manager.d.ts.map