import type { IAdminRepository } from '../db/repository-types';
/**
 * מנוע הרצת מבצעים שרתי — רץ ברקע גם ללא משתמש מחובר.
 * סורק מבצעים פעילים עם schedule ומריץ אותם דרך pipeline קיים.
 */
export declare class ServerOperationScheduler {
    private store;
    private state;
    constructor(store: IAdminRepository);
    start(): void;
    stop(): void;
    private tick;
    private shouldSkip;
    private isScheduleDue;
    private executeOperation;
    private resolveApiKey;
}
//# sourceMappingURL=operation-scheduler.d.ts.map