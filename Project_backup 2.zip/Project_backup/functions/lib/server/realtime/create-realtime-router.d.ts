import { Router } from 'express';
import type { IAdminRepository } from '../db/repository-types';
interface RealtimeRouterDeps {
    store: IAdminRepository;
}
/**
 * נתיבי Realtime עבור מצב Ghost ON:
 *   - POST /api/realtime/session         → מנפיק ephemeral token לשיחת WebRTC ישירה לדפדפן
 *   - POST /api/realtime/alert-summary   → מפיק טקסט התראה קצר + תיאור עומק של הפריים
 *
 * האודיו לא עובר דרך השרת. השרת רק מנפיק את ה-token ומכין את הטקסטים.
 */
export declare function createRealtimeRouter({ store }: RealtimeRouterDeps): Router;
export {};
//# sourceMappingURL=create-realtime-router.d.ts.map