import type { IRealtimeHub, LiveEventPayload } from './realtime-hub-types';
/**
 * מרכז אירועים בזמן אמת דרך Firebase Realtime Database (סביבת פרודקשן).
 * כותב אירועים תחת realtime/{orgId}/events/{pushId} עם TTL אוטומטי.
 */
export declare class FirebaseRealtimeHub implements IRealtimeHub {
    publish(event: LiveEventPayload): void;
}
//# sourceMappingURL=firebase-hub.d.ts.map