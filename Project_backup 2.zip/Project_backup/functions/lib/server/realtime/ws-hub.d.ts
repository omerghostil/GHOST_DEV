import type { Server as HttpServer } from 'node:http';
import type { IRealtimeHub, LiveEventPayload } from './realtime-hub-types';
/**
 * מרכז אירועים בזמן אמת דרך WebSocket לממשק סופר־אדמין (סביבת פיתוח).
 */
export declare class RealtimeHub implements IRealtimeHub {
    private readonly wss;
    constructor(server: HttpServer);
    publish(event: LiveEventPayload): void;
}
export type { LiveEventPayload, IRealtimeHub };
//# sourceMappingURL=ws-hub.d.ts.map