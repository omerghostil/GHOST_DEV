import { z } from 'zod';
export declare const CreateChannelSchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodEnum<{
        personal: "personal";
        group: "group";
    }>;
    subtitle: z.ZodDefault<z.ZodString>;
    location: z.ZodDefault<z.ZodString>;
    watchScope: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
    memoryInterval: z.ZodDefault<z.ZodNumber>;
    rtspFeed: z.ZodDefault<z.ZodString>;
    liveState: z.ZodDefault<z.ZodEnum<{
        LIVE: "LIVE";
        SYNC: "SYNC";
        DEGRADED: "DEGRADED";
        OFFLINE: "OFFLINE";
    }>>;
    cameraEnabled: z.ZodDefault<z.ZodBoolean>;
    linkedChannelIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    members: z.ZodDefault<z.ZodArray<z.ZodString>>;
    isBlocked: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strip>;
export declare const UpdateChannelSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    type: z.ZodOptional<z.ZodEnum<{
        personal: "personal";
        group: "group";
    }>>;
    subtitle: z.ZodOptional<z.ZodString>;
    location: z.ZodOptional<z.ZodString>;
    watchScope: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    memoryInterval: z.ZodOptional<z.ZodNumber>;
    rtspFeed: z.ZodOptional<z.ZodString>;
    liveState: z.ZodOptional<z.ZodEnum<{
        LIVE: "LIVE";
        SYNC: "SYNC";
        DEGRADED: "DEGRADED";
        OFFLINE: "OFFLINE";
    }>>;
    cameraEnabled: z.ZodOptional<z.ZodBoolean>;
    linkedChannelIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    members: z.ZodOptional<z.ZodArray<z.ZodString>>;
    isBlocked: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export declare const CreateMessageSchema: z.ZodObject<{
    author: z.ZodEnum<{
        user: "user";
        system: "system";
        ghost: "ghost";
    }>;
    text: z.ZodString;
    time: z.ZodString;
    alertLevel: z.ZodOptional<z.ZodEnum<{
        report: "report";
        rating: "rating";
        assessment: "assessment";
        critical: "critical";
        routine: "routine";
    }>>;
    score: z.ZodOptional<z.ZodNumber>;
    frameDataUrl: z.ZodOptional<z.ZodString>;
    sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const CreateOperationSchema: z.ZodObject<{
    name: z.ZodString;
    mode: z.ZodEnum<{
        alert: "alert";
        report: "report";
        rating: "rating";
        assessment: "assessment";
    }>;
    schedule: z.ZodDefault<z.ZodString>;
    trigger: z.ZodDefault<z.ZodString>;
    action: z.ZodString;
    modelOverride: z.ZodOptional<z.ZodEnum<{
        "gpt-4.1": "gpt-4.1";
        "gpt-4.1-mini": "gpt-4.1-mini";
    }>>;
    detailLevel: z.ZodOptional<z.ZodEnum<{
        low: "low";
        auto: "auto";
        high: "high";
    }>>;
    enabled: z.ZodDefault<z.ZodBoolean>;
    parsedSchedule: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
export declare const UpdateOperationSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    mode: z.ZodOptional<z.ZodEnum<{
        alert: "alert";
        report: "report";
        rating: "rating";
        assessment: "assessment";
    }>>;
    schedule: z.ZodOptional<z.ZodString>;
    trigger: z.ZodOptional<z.ZodString>;
    action: z.ZodOptional<z.ZodString>;
    modelOverride: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        "gpt-4.1": "gpt-4.1";
        "gpt-4.1-mini": "gpt-4.1-mini";
    }>>>;
    detailLevel: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        low: "low";
        auto: "auto";
        high: "high";
    }>>>;
    enabled: z.ZodOptional<z.ZodBoolean>;
    parsedSchedule: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
}, z.core.$strip>;
//# sourceMappingURL=schemas.d.ts.map