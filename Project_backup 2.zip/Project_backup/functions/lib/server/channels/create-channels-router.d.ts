import { Router } from 'express';
import type { IAdminRepository } from '../db/repository-types';
import type { IRealtimeHub } from '../realtime/realtime-hub-types';
interface ChannelsRouterDeps {
    store: IAdminRepository;
    realtimeHub: IRealtimeHub;
}
export declare function createChannelsRouter({ store, realtimeHub }: ChannelsRouterDeps): Router;
export {};
//# sourceMappingURL=create-channels-router.d.ts.map