import OpenAI from 'openai';
import { z } from 'zod';
import { type ChatVisionRequest, type OperationScanRequest, type OperationScanResponse } from './schemas';
import type { VisionDetailLevel } from './image-optimizer';
/**
 * נשלח למודל ה-Realtime (קולי) כשנפתחת שיחת Ghost ON על התראה קריטית.
 * יורש את כללי הזהות, הגנה והאישיות מ-GHOST_CHAT_SYSTEM_PROMPT,
 * ומוסיף הנחיות ספציפיות לייעוץ קולי דו-כיווני קצר.
 */
export declare const GHOST_VOICE_SYSTEM_PROMPT: string;
interface AlertVoiceInput {
    channel: {
        name: string;
        location: string;
        watchScope: string;
    };
    operationName: string;
    scanSummary: string;
    frameDataUrl: string;
    occurredAtIso: string;
    operatorDisplayName: string;
}
interface AlertVoiceTextResult {
    alertText: string;
    deepFrameDescription: string;
}
/**
 * מנפיק שני פלטים מקבילים:
 *   1. תיאור עומק של הפריים (2-3 משפטים, ממוקדי-עובדות).
 *   2. משפט התראה קולי קצר (8-12 מילים) שמותאם אישית למבצע ולקצין.
 *
 * שני התהליכים רצים במקביל ב-Promise.all כדי לחסוך זמן בעת התראה חיה.
 * אכיפת אורך נעשית כ-safety net בצד שרת על ידי חיתוך ל-12 מילים.
 */
export declare function requestAlertVoiceText(input: AlertVoiceInput, openai: OpenAI): Promise<AlertVoiceTextResult>;
export interface VisionRequestOptions {
    model: string;
    detail: VisionDetailLevel;
    apiKey?: string;
    signal?: AbortSignal;
}
/**
 * מחלץ טקסט תשובה אחיד ממבנה ה-Responses API.
 */
export declare function extractResponseText(response: OpenAI.Responses.Response): string;
/**
 * מנסה לפרק JSON מתשובת מודל (כולל גדרות markdown).
 */
export declare function parseJsonFromModelText(raw: string): unknown;
/**
 * מזהה ניסיון לחשוף מידע פנימי על המערכת או על מנגנון ההפעלה.
 */
export declare function isInternalDisclosureAttempt(prompt: string): boolean;
/**
 * תגובה רכה בקול Ghost כשמזהים ניסיון חילוץ זהות.
 * נבחרת באופן אקראי כדי לא לחזור על אותו ניסוח.
 */
export declare function buildSecurityRefusalResponse(): string;
/**
 * מריץ ניתוח תמונה לצ'אט משתמש עם מודל ורמת פירוט דינמיים.
 */
export declare function requestVisionAnalysis(payload: ChatVisionRequest, frameDataUrl: string, options: VisionRequestOptions): Promise<string>;
/**
 * מריץ סריקת מבצעים ומחזיר JSON מאומת בלבד.
 */
export declare function requestOperationScanAnalysis(payload: OperationScanRequest, frameDataUrl: string, options: VisionRequestOptions): Promise<OperationScanResponse>;
export declare function isOpenAiConfigured(): boolean;
/**
 * סכמת דו"ח ייעוץ קולי. מיועד לסיום שיחת Ghost ON על התראה קריטית.
 * מודל המסקנות מחזיר מבנה זה תחת structured output (json_schema, strict).
 */
export declare const ConsultationReportSchema: z.ZodObject<{
    summaryParagraph: z.ZodString;
    identifiedEntities: z.ZodObject<{
        people: z.ZodArray<z.ZodObject<{
            description: z.ZodString;
            clothing: z.ZodOptional<z.ZodString>;
            ageGroup: z.ZodOptional<z.ZodEnum<{
                ילד: "ילד";
                נער: "נער";
                צעיר: "צעיר";
                בוגר: "בוגר";
                מבוגר: "מבוגר";
            }>>;
            distinguishingFeatures: z.ZodOptional<z.ZodString>;
            observedBehavior: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        vehicles: z.ZodArray<z.ZodObject<{
            type: z.ZodString;
            color: z.ZodOptional<z.ZodString>;
            licensePlate: z.ZodOptional<z.ZodString>;
            distinguishingFeatures: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        objects: z.ZodArray<z.ZodObject<{
            description: z.ZodString;
            location: z.ZodOptional<z.ZodString>;
            significance: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        behaviors: z.ZodArray<z.ZodString>;
        locations: z.ZodArray<z.ZodString>;
        timeReferences: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    recommendedActions: z.ZodArray<z.ZodString>;
    riskAssessment: z.ZodEnum<{
        low: "low";
        high: "high";
        critical: "critical";
        medium: "medium";
    }>;
    conversationHighlights: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type ConsultationReport = z.infer<typeof ConsultationReportSchema>;
export interface ConsultationAnalysisInput {
    channel: {
        id: string;
        name: string;
        location: string;
        watchScope: string;
        type: 'personal' | 'group';
        members: string[];
    };
    operation: {
        id: string;
        name: string;
        mode: 'alert' | 'report' | 'rating' | 'assessment';
        trigger?: string;
        action?: string;
    };
    alertText: string;
    deepFrameDescription: string;
    scanSummary: string;
    frameDataUrl: string;
    occurredAtIso: string;
    operatorDisplayName: string;
    conversationTurns: Array<{
        role: 'user' | 'assistant';
        text: string;
        capturedAtIso: string;
    }>;
}
/**
 * מבצע ניתוח מלא של שיחת ייעוץ Ghost ON: סיכום + ישויות מזוהות + המלצות + רמת סיכון.
 *
 * שולח את הפריים שגרם להתראה כ-input_image, ואת התמלול הדו-כיווני כטקסט מובנה.
 * משתמש ב-structured output של Responses API (json_schema strict) כדי להבטיח
 * שהמודל יחזיר בדיוק את הסכמה הנדרשת — בלי ניחושים בצד הלקוח.
 *
 * אם המודל מחזיר JSON שאינו עומד בסכמה — נזרקת שגיאה ברורה. נופלים ב-router
 * חזרה ל-502 ידידותי, ולא משבשים את ה-UX של סיום השיחה.
 */
export declare function requestConsultationAnalysis(input: ConsultationAnalysisInput, openai: OpenAI): Promise<ConsultationReport>;
export {};
//# sourceMappingURL=vision-handler.d.ts.map