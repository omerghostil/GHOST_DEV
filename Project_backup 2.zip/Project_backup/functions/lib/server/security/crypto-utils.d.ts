/**
 * יוצר hash סיסמה דטרמיניסטי עם salt קבוע לסביבה המקומית.
 */
export declare function hashPassword(rawPassword: string): string;
/**
 * בודק התאמת סיסמה בצורה בטוחה לזמן.
 */
export declare function verifyPassword(rawPassword: string, expectedHash: string): boolean;
/**
 * מצפין ערך רגיש לשמירה בדאטה־סטור.
 */
export declare function encryptSensitiveValue(rawValue: string): string;
/**
 * מפענח ערך רגיש מהאחסון.
 */
export declare function decryptSensitiveValue(payload: string): string;
export declare function maskPan(pan: string): string;
//# sourceMappingURL=crypto-utils.d.ts.map