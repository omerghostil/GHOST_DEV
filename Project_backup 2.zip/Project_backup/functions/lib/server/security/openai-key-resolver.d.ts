import OpenAI from 'openai';
import type { IAdminRepository } from '../db/repository-types';
/**
 * מאחזר מפתח OpenAI לארגון (אם הוגדר) או נופל למפתח גלובלי מהסביבה.
 * משמש בכל מקום בשרת שצריך לבצע קריאה ל-OpenAI בשם משתמש מאומת.
 */
export declare function resolveOpenAiApiKey(store: IAdminRepository, organizationId?: string): string | undefined;
/**
 * בונה OpenAI client לבקשה אחת. מחזיר null אם לא הוגדר אף מפתח.
 */
export declare function buildOpenAiClientForOrg(store: IAdminRepository, organizationId?: string): OpenAI | null;
//# sourceMappingURL=openai-key-resolver.d.ts.map