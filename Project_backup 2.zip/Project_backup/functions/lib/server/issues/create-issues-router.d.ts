import { Router } from 'express';
import type { IAdminRepository } from '../db/repository-types';
import type { IRealtimeHub } from '../realtime/realtime-hub-types';
interface CreateIssuesRouterOptions {
    store: IAdminRepository;
    realtimeHub: IRealtimeHub;
}
/**
 * נתיבי דיווח תקלות מהמשתמשים בזמן אמת.
 */
export declare function createIssuesRouter({ store, realtimeHub }: CreateIssuesRouterOptions): Router;
export {};
//# sourceMappingURL=create-issues-router.d.ts.map