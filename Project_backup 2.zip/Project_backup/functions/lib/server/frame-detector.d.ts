interface DetectionPrediction {
    class: string;
    score?: number;
}
interface DetectionModel {
    detect(input: unknown): Promise<DetectionPrediction[]>;
}
interface DisposableTensor {
    dispose: () => void;
}
interface DetectorDependencies {
    loadModel: () => Promise<DetectionModel>;
    decodeImage: (imageBuffer: Buffer) => Promise<DisposableTensor>;
    nowMs: () => number;
    cpuUsage: (previous?: NodeJS.CpuUsage) => NodeJS.CpuUsage;
    memoryUsage: () => NodeJS.MemoryUsage;
    logInfo: (message: string) => void;
    logError: (message: string) => void;
}
/**
 * פותר סף ביטחון מהסביבה עם ברירת מחדל בטוחה.
 */
export declare function resolveConfidenceThreshold(raw: string | undefined): number;
/**
 * מחלץ בייטים מתוך data URL של תמונה ומוודא פורמט תקין.
 */
export declare function parseImageDataUrl(frameDataUrl: string): Buffer;
/**
 * קובע האם אחת התוצאות עומדת בסף והינה אדם/רכב.
 */
export declare function isFrameRelevantByDetections(detections: DetectionPrediction[], confidenceThreshold: number): boolean;
/**
 * יוצר בודק רלוונטיות פריים עם הזרקת תלויות לצורך בדיקות.
 */
export declare function createFrameRelevanceDetector(overrides?: Partial<DetectorDependencies>): (frameDataUrl: string) => Promise<boolean>;
/**
 * מזהה האם פריים כולל אדם/רכב באמצעות מודל COCO-SSD מקומי.
 */
export declare const detectFrameRelevance: (frameDataUrl: string) => Promise<boolean>;
export {};
//# sourceMappingURL=frame-detector.d.ts.map