import type { RequestHandler } from 'express';
import { z } from 'zod';
export declare const FrameRelevanceRequestSchema: z.ZodObject<{
    frameDataUrl: z.ZodString;
}, z.core.$strip>;
interface FrameRelevanceRouteDependencies {
    enqueueTask: <T>(task: () => Promise<T>) => Promise<T>;
    detectFrameRelevance: (frameDataUrl: string) => Promise<boolean>;
}
/**
 * בונה handler ל-API רלוונטיות פריים עם תלות בזיהוי לוקאלי.
 */
export declare function createFrameRelevanceRouteHandler({ enqueueTask, detectFrameRelevance, }: FrameRelevanceRouteDependencies): RequestHandler;
export {};
//# sourceMappingURL=frame-relevance-route.d.ts.map